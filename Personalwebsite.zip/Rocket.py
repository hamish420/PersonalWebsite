#this is just a py file so the code wont work

#this was the first generation code anyone that knows arduino knows this code is very basic

#include <Servo.h>

Servo myServo;

int servoDelay2=1100;
int servoDelay=500;
int servoMax=180;
int servoMin=0;
int iPin=11;
int ipin2=9;

void setup() {
  // put your setup code here, to run once:
  pinMode(iPin, OUTPUT);
  pinMode(ipin2, OUTPUT);
  myServo.attach(6);
}

void loop() {
  // put your main code here, to run repeatedly:
  digitalWrite(iPin, LOW);
  delay(12600);
  digitalWrite(iPin, HIGH);
  delay(100);

  
  digitalWrite(ipin2, LOW);
  delay(10000);
  digitalWrite(ipin2, HIGH);
  delay(100);
  
  myServo.write(servoMax);
  delay(servoDelay);

  myServo.write(servoMin);
  delay(servoDelay2);
} 

#Download the Arduino ide and try this code!

#second generation code in the making!